# Wind Assist (Fabric 1.21.11)

Client-side Fabric mod source project. Requires Java 21, Fabric Loader 0.18.1+, and Fabric API 0.141.6+1.21.11.

## Controls
- `V`: toggle Aim Assist
- `Right Shift`: open settings menu

## Features
- Players and vanilla `Mob` targets can be enabled independently.
- Friend names are case-insensitive and ignored by the target selector.
- Range, FOV and subtle correction strength are configurable in the menu.
- Settings are saved to `config/windassist.properties`.
- No automatic attacks or attack packets are sent.

## Build
Run `gradle build` with JDK 21 and Gradle 9.2+ in this directory. The distributable jar is in `build/libs/`.

This project targets Minecraft 1.21.11 with official Mojang mappings and Fabric Loom 1.14.x.
