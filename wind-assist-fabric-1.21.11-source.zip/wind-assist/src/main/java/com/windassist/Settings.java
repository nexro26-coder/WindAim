package com.windassist;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

public final class Settings {
    public boolean enabled = false;
    public boolean players = true;
    public boolean mobs = true;
    public double range = 3.0;
    public float fov = 30.0f;
    public float strength = 0.18f;
    public float maxStep = 1.60f;
    public final Set<String> friends = new LinkedHashSet<>();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("windassist.properties");

    public boolean isFriend(String name) { return friends.contains(name.toLowerCase(Locale.ROOT)); }
    public void addFriend(String name) {
        String clean = name == null ? "" : name.trim();
        if (!clean.isEmpty()) friends.add(clean.toLowerCase(Locale.ROOT));
    }
    public void removeFriend(String name) {
        if (name != null) friends.remove(name.trim().toLowerCase(Locale.ROOT));
    }

    public void load() {
        if (!Files.exists(file)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
            enabled = Boolean.parseBoolean(p.getProperty("enabled", "false"));
            players = Boolean.parseBoolean(p.getProperty("players", "true"));
            mobs = Boolean.parseBoolean(p.getProperty("mobs", "true"));
            range = parseDouble(p.getProperty("range"), 3.0, 1.0, 6.0);
            fov = (float) parseDouble(p.getProperty("fov"), 30.0, 1.0, 30.0);
            strength = (float) parseDouble(p.getProperty("strength"), 0.18, 0.01, 0.30);
            maxStep = (float) parseDouble(p.getProperty("maxStep"), 1.60, 0.1, 3.0);
            String list = p.getProperty("friends", "");
            for (String friend : list.split(",")) addFriend(friend);
        } catch (Exception ignored) { }
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("enabled", Boolean.toString(enabled));
        p.setProperty("players", Boolean.toString(players));
        p.setProperty("mobs", Boolean.toString(mobs));
        p.setProperty("range", Double.toString(range));
        p.setProperty("fov", Float.toString(fov));
        p.setProperty("strength", Float.toString(strength));
        p.setProperty("maxStep", Float.toString(maxStep));
        p.setProperty("friends", String.join(",", friends));
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) { p.store(out, "Wind Assist settings"); }
        } catch (Exception ignored) { }
    }

    private static double parseDouble(String value, double fallback, double min, double max) {
        try { return Math.max(min, Math.min(max, Double.parseDouble(value))); }
        catch (Exception ignored) { return fallback; }
    }
}
