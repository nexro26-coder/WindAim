package com.windassist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class WindAssistScreen extends Screen {
    private EditBox friendInput;
    private int friendScroll = 0;

    public WindAssistScreen() { super(Component.literal("Wind Assist")); }

    @Override
    protected void init() {
        int left = this.width / 2 - 155;
        int top = this.height / 2 - 112;
        addRenderableWidget(Button.builder(toggleLabel(), b -> {
            WindAssistClient.SETTINGS.enabled = !WindAssistClient.SETTINGS.enabled;
            WindAssistClient.SETTINGS.save(); b.setMessage(toggleLabel());
        }).bounds(left, top, 150, 20).build());
        addRenderableWidget(Button.builder(playersLabel(), b -> {
            WindAssistClient.SETTINGS.players = !WindAssistClient.SETTINGS.players;
            WindAssistClient.SETTINGS.save(); b.setMessage(playersLabel());
        }).bounds(left + 160, top, 150, 20).build());
        addRenderableWidget(Button.builder(mobsLabel(), b -> {
            WindAssistClient.SETTINGS.mobs = !WindAssistClient.SETTINGS.mobs;
            WindAssistClient.SETTINGS.save(); b.setMessage(mobsLabel());
        }).bounds(left, top + 26, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Range: " + fmt(WindAssistClient.SETTINGS.range) + " blocks"), b -> {
            WindAssistClient.SETTINGS.range = WindAssistClient.SETTINGS.range >= 6.0 ? 2.0 : Math.min(6.0, WindAssistClient.SETTINGS.range + 1.0);
            WindAssistClient.SETTINGS.save(); b.setMessage(Component.literal("Range: " + fmt(WindAssistClient.SETTINGS.range) + " blocks"));
        }).bounds(left + 160, top + 26, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("FOV: " + fmt(WindAssistClient.SETTINGS.fov) + "°"), b -> {
            WindAssistClient.SETTINGS.fov = WindAssistClient.SETTINGS.fov >= 12.0f ? 2.0f : Math.min(12.0f, WindAssistClient.SETTINGS.fov + 2.0f);
            WindAssistClient.SETTINGS.save(); b.setMessage(Component.literal("FOV: " + fmt(WindAssistClient.SETTINGS.fov) + "°"));
        }).bounds(left, top + 52, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Strength: " + fmt(WindAssistClient.SETTINGS.strength)), b -> {
            WindAssistClient.SETTINGS.strength = WindAssistClient.SETTINGS.strength >= 0.30f ? 0.05f : Math.min(0.30f, WindAssistClient.SETTINGS.strength + 0.05f);
            WindAssistClient.SETTINGS.save(); b.setMessage(Component.literal("Strength: " + fmt(WindAssistClient.SETTINGS.strength)));
        }).bounds(left + 160, top + 52, 150, 20).build());

        friendInput = new EditBox(font, left, top + 102, 220, 20, Component.literal("Player name"));
        friendInput.setHint(Component.literal("Friend username"));
        addRenderableWidget(friendInput);
        addRenderableWidget(Button.builder(Component.literal("Add friend"), b -> {
            WindAssistClient.SETTINGS.addFriend(friendInput.getValue());
            friendInput.setValue(""); WindAssistClient.SETTINGS.save();
        }).bounds(left + 230, top + 102, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Remove typed name"), b -> {
            String value = friendInput.getValue();
            WindAssistClient.SETTINGS.removeFriend(value);
            WindAssistClient.SETTINGS.save();
        }).bounds(left, top + 128, 150, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + 160, top + 154, 150, 20).build());
    }

    private Component toggleLabel() { return Component.literal("Aim Assist: " + (WindAssistClient.SETTINGS.enabled ? "ON" : "OFF")); }
    private Component playersLabel() { return Component.literal("Players: " + (WindAssistClient.SETTINGS.players ? "ON" : "OFF")); }
    private Component mobsLabel() { return Component.literal("Mobs: " + (WindAssistClient.SETTINGS.mobs ? "ON" : "OFF")); }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int left = this.width / 2 - 155;
        int top = this.height / 2 - 112;
        graphics.drawCenteredString(font, "WIND ASSIST  |  SUBTLE", width / 2, top - 22, 0xFFFFFFFF);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawString(font, "FRIEND LIST (names are case-insensitive)", left, top + 82, 0xFFB8C8D8);
        List<String> friends = new ArrayList<>(WindAssistClient.SETTINGS.friends);
        String display = friends.isEmpty() ? "No friends added" : String.join(", ", friends);
        graphics.drawString(font, display, left, top + 155, 0xFFFFFFFF, false);
        graphics.drawString(font, "V: toggle  |  Right Shift: menu", left, top + 181, 0xFF9AA7B5);
    }

    @Override
    public void onClose() {
        WindAssistClient.SETTINGS.save();
        Minecraft.getInstance().setScreen(null);
    }

    private static String fmt(double value) { return String.format(java.util.Locale.ROOT, "%.2f", value); }
}
