package com.windassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public final class WindAssistClient implements ClientModInitializer {
    public static final Settings SETTINGS = new Settings();
    private static KeyMapping toggleKey;
    private static KeyMapping menuKey;

    @Override
    public void onInitializeClient() {
        SETTINGS.load();
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.windassist.toggle", GLFW.GLFW_KEY_V, KeyMapping.Category.MISC));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.windassist.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                SETTINGS.enabled = !SETTINGS.enabled;
                SETTINGS.save();
                if (client.player != null) client.player.displayClientMessage(
                        Component.literal("Wind Assist: " + (SETTINGS.enabled ? "ON" : "OFF")), true);
            }
            while (menuKey.consumeClick()) client.setScreen(new WindAssistScreen());
            if (SETTINGS.enabled) applyAssist(client);
        });
    }

    private static void applyAssist(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.screen != null || player.isSpectator() || player.isPassenger()) return;

        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        Entity best = null;
        Vec3 bestPoint = null;
        double bestAngle = Double.MAX_VALUE;
        double maxRange = SETTINGS.range;

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == player || !entity.isAlive() || entity.isRemoved()) continue;
            boolean isPlayer = entity instanceof Player;
            boolean isMob = entity instanceof Mob;
            if ((isPlayer && !SETTINGS.players) || (isMob && !SETTINGS.mobs) || (!isPlayer && !isMob)) continue;
            if (isPlayer && SETTINGS.isFriend(entity.getName().getString())) continue;
            if (entity.isSpectator() || !player.hasLineOfSight(entity)) continue;

            AABB box = entity.getBoundingBox();
            Vec3 center = box.getCenter();
            double distance = eye.distanceTo(center);
            if (distance > maxRange) continue;

            // Find the point on the hitbox nearest to the current view ray.
            double along = Math.max(0.0, Math.min(distance, center.subtract(eye).dot(look)));
            Vec3 rayPoint = eye.add(look.scale(along));
            Vec3 point = new Vec3(
                    clamp(rayPoint.x, box.minX, box.maxX),
                    clamp(rayPoint.y, box.minY, box.maxY),
                    clamp(rayPoint.z, box.minZ, box.maxZ));
            Vec3 toPoint = point.subtract(eye);
            if (toPoint.lengthSqr() < 1.0E-6) continue;
            double angle = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, look.dot(toPoint.normalize())))));
            if (angle > SETTINGS.fov || angle >= bestAngle) continue;
            best = entity;
            bestPoint = point;
            bestAngle = angle;
        }

        if (best == null || bestPoint == null) return;
        Vec3 delta = bestPoint.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));

        // Low-gain proportional correction; never snaps or takes over the camera.
        float gain = SETTINGS.strength * (float) Math.max(0.10, 1.0 - bestAngle / SETTINGS.fov);
        float yawError = wrapDegrees(targetYaw - player.getYRot());
        float pitchError = targetPitch - player.getXRot();
        float yawStep = clamp((float) (yawError * gain), -SETTINGS.maxStep, SETTINGS.maxStep);
        float pitchStep = clamp((float) (pitchError * gain * 0.65), -SETTINGS.maxStep * 0.65f, SETTINGS.maxStep * 0.65f);
        player.setYRot(player.getYRot() + yawStep);
        player.setXRot(clamp(player.getXRot() + pitchStep, -90.0f, 90.0f));
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    private static float wrapDegrees(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }
}
